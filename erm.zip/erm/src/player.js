// ---- Character ----
function define_hito(startingPositionX = 0, startingPositionY = 0) {

  var hito = Crafty.e("2D, DOM, HitoSprite, SpriteAnimation, Twoway");

  hito.gemsCollected = 0;
  hito.inMotion = false;

  // starting position
  hito.x = startingPositionX;
  hito.y = startingPositionY;

  // Movement
  hito.twoway(2, 3)
  .gravity('Floor')

  // Animation
  .reel('walkRight', 500, [[0, 17], [17, 17], [34, 17], [17, 17]])
  .reel('walkLeft', 500, [[0, 34], [17, 34], [34, 34], [17, 34]])
  .reel('idle', 1000, [[0, 0], [17, 0], [34, 0]])

  .bind('NewDirection', function(data) {
    if (data.x > 0) {
      this.animate('walkRight', -1);
      this.inMotion = true;
    } else if (data.x < 0) {
      this.animate('walkLeft', -1);
      this.inMotion = true;
    } else {
      this.animate('idle', -1);
      this.inMotion = false;
    }
  })

  // Collision Detection - Walls
  .addComponent("Collision").bind('Moved', function(from) {
    if(this.hit('Wall')) {
        this.attr({x: from.x});
    }
  })

  // Collision Detection - Gems
  .onHit("Gem",function(hit){ collectGem(hit, this); })

  // Collision Detection - Gremlins
  .onHit("GremlinSprite",function(hit){ hitGremlin(hit, this); });

  return hito;
}

function collectGem(hit, hito) {

  // remove gem object
  hit[0].obj.destroy();

  // increment gem collected stat
  hito.gemsCollected++;

  // play sound
  Crafty.audio.play("gem", 1);

  // create a following gem character
  var follow_gem = Crafty.e("2D, Canvas, SpriteAnimation, GemSprite, gemFollow")
      .attr({x: hito.x, y: hito.y, w: 16, h: 16})
      .reel('gemSparkle', 500, [[0, 0], [16, 0], [32, 0], [16, 0]])
      .animate('gemSparkle', -1)
      .followPlayer(hito.gemsCollected);
}

function hitGremlin(gremlin, hito) {

    // change dir of gremlin
    if (gremlin._facingRight) {
      gremlin._facingRight = false;
    } else {
      gremlin._facingRight = true;
    }
}
